package odda.technologies.etudiantEvaluation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EtudiantEvaluationBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
